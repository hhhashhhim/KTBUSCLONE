<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\v1\AuthApiController;
use App\Http\Controllers\Api\v1\BookingApiController;
use App\Http\Controllers\Api\v1\TicketingApiController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });


// Route::post('register', [RegisterController::class, 'register']);
Route::post('login', [AuthApiController::class, 'login']);

Route::group(['middleware' => 'auth:sanctum'], function(){
   //All secure URL's
   Route::group(['prefix'=>'booking'],function(){
      Route::post('/cities/departures',[BookingApiController::class,'departureCities']);
      Route::post('/cities/destinations',[BookingApiController::class,'destinationCities']);
      Route::post('/schedules/available',[BookingApiController::class,'availableSchedules']);
      Route::post('/schedule/preview',[BookingApiController::class,'previewSchedule']);
      Route::post('/new',[BookingApiController::class,'bookSeat']);
   });
   
   Route::group(['prefix'=>'ticketing'],function(){
      Route::post('/schedules/available',[TicketingApiController::class,'availableSchedules']);
      Route::post('/schedule/preview',[TicketingApiController::class,'previewSchedule']);
      Route::post('/new',[TicketingApiController::class,'bookSeat']);
   });
});